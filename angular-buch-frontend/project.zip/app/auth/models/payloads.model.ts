export interface CreatePayload {
  id: number | null;
}

export interface UpdatePayload {
  version: number | null;
}
