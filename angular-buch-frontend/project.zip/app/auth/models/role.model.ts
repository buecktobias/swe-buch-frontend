export enum Role {
  ADMIN = 'admin',
  USER = 'user',
  GUEST = 'guest',
}
