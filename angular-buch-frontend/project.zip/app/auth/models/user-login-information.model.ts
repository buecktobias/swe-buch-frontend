export interface UserLoginInformation {
  readonly username: string;
  readonly password: string;
}
