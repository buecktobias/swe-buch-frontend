export interface Abbildung {
  beschriftung: string;
  contentType: string | null;
}
