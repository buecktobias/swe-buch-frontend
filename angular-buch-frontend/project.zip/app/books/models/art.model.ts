export enum Art {
  EPUB = 'EPUB',
  HARDCOVER = 'HARDCOVER',
  PAPERBACK = 'PAPERBACK',
}
