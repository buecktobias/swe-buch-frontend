export interface Titel {
  titel: string;
  untertitel: string | null;
}
