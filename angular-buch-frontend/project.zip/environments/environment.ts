import { EnvironmentConfig, LogLevel } from './environment.config';

export const environment: EnvironmentConfig = {
  logLevel: LogLevel.DEBUG,
};
